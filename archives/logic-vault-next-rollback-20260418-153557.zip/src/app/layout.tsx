import type { Metadata } from "next";
import "./globals.css";

import { Footer } from "@/components/footer";
import { GlobalAdProvider } from "@/components/global-ad-provider";
import { Header } from "@/components/header";
import { JsonLd } from "@/components/json-ld";
import { CookieConsent } from "@/components/cookie-consent";
import { LanguageSuggestion } from "@/components/language-suggestion";
import { VaultProvider } from "@/context/vault-context";
import { getSiteConfig } from "@/lib/config-provider";
import {
  GLOBAL_KEYWORDS,
  buildOrganizationSchema,
  buildWebsiteSchema,
} from "@/lib/seo";
import { buildAlternateLanguages, SITE_NAME, SITE_URL } from "@/lib/site";

export async function generateMetadata(): Promise<Metadata> {
  const config = await getSiteConfig();

  return {
    metadataBase: new URL(SITE_URL),
    applicationName: SITE_NAME,
    title: config.metaTitle,
    description: config.metaDescription,
    keywords: GLOBAL_KEYWORDS,
    authors: [{ name: SITE_NAME, url: SITE_URL }],
    creator: SITE_NAME,
    publisher: SITE_NAME,
    category: "BusinessApplication",
    referrer: "origin-when-cross-origin",
    alternates: {
      canonical: "/",
      languages: buildAlternateLanguages("/"),
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-image-preview": "large",
        "max-snippet": -1,
        "max-video-preview": -1,
      },
    },
    openGraph: {
      title: config.metaTitle,
      description: config.metaDescription,
      url: "/",
      siteName: "Logic Vault",
      type: "website",
      images: [config.openGraphImage],
    },
    twitter: {
      card: "summary_large_image",
      title: config.metaTitle,
      description: config.metaDescription,
      images: [config.openGraphImage],
    },
    appleWebApp: {
      capable: true,
      title: SITE_NAME,
      statusBarStyle: "default",
    },
    formatDetection: {
      telephone: false,
      date: false,
      address: false,
      email: false,
    },
    icons: {
      icon: [
        { url: "/favicon.ico", sizes: "any" },
        { url: "/icon.svg", type: "image/svg+xml" },
        { url: "/icon.png", type: "image/png", sizes: "512x512" },
      ],
      shortcut: "/favicon.ico",
      apple: [
        { url: "/apple-touch-icon.png", type: "image/png", sizes: "180x180" },
      ],
    },
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const config = await getSiteConfig();

  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full bg-[#f3f4f6] font-sans text-slate-950">
        <JsonLd data={[buildOrganizationSchema(), buildWebsiteSchema()]} />
        <GlobalAdProvider config={config}>
          <VaultProvider>
            <Header />
            <LanguageSuggestion />
            {children}
            <Footer />
            <CookieConsent />
          </VaultProvider>
        </GlobalAdProvider>
      </body>
    </html>
  );
}
