import Link from "next/link";

export default function NotFoundPage() {
  return (
    <main className="bg-[#f3f4f6] px-4 pb-16 pt-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-2xl rounded-[32px] border border-vault-border bg-white px-6 py-10 text-center shadow-sm">
        <p className="text-sm font-semibold uppercase tracking-[0.28em] text-slate-400">404</p>
        <h1 className="mt-4 text-3xl font-black text-slate-950">That page could not be found.</h1>
        <p className="mt-3 text-sm leading-7 text-slate-500">
          The page may have moved, the tool slug may be wrong, or the route is intentionally hidden.
        </p>
        <Link
          href="/"
          className="mt-6 inline-flex items-center justify-center rounded-full bg-vault-red px-6 py-3 text-sm font-semibold text-white transition hover:bg-[#cb2d29]"
        >
          Back to Dashboard
        </Link>
      </div>
    </main>
  );
}
