"use client";

import { useEffect, useRef, useState } from "react";

import { useGlobalSiteConfig } from "@/components/global-ad-provider";
import { AD_SLOT_DEFINITIONS, type AdSlotName } from "@/lib/ad-slots";

interface AdSlotProps {
  slot: AdSlotName;
  className?: string;
  label?: string;
}

export function AdSlot({ slot, className = "", label }: AdSlotProps) {
  const { adSlots } = useGlobalSiteConfig();
  const [isVisible, setIsVisible] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const slotConfig = adSlots[slot];
  const slotDetails = AD_SLOT_DEFINITIONS[slot];
  const hasCreative = Boolean(slotConfig?.script.trim());

  useEffect(() => {
    const node = containerRef.current;

    if (!node) {
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin: "200px" }
    );

    observer.observe(node);

    return () => observer.disconnect();
  }, []);

  if (!slotConfig?.enabled || !hasCreative) {
    return null;
  }

  return (
    <div
      ref={containerRef}
      className={`rounded-[24px] border border-vault-border bg-white/90 p-4 text-center ${className}`}
    >
      <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-slate-400">
        {label ?? slotDetails.label}
      </p>

      {isVisible ? (
        slotConfig.script && process.env.NODE_ENV === "production" ? (
          <div
            className="mt-3 min-h-[90px]"
            dangerouslySetInnerHTML={{ __html: slotConfig.script }}
          />
        ) : (
          <div className="mt-3 rounded-2xl border border-dashed border-vault-border bg-slate-50 px-4 py-8 text-sm text-slate-500">
            {slotDetails.label} is configured in admin and will render here in production.
          </div>
        )
      ) : (
        <div className="mt-3 h-[120px] animate-pulse rounded-2xl bg-slate-100" />
      )}
    </div>
  );
}
