"use client";

import { ShieldCheck, Sparkles } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import type { MathCaptchaChallenge } from "@/lib/security";

const PURPOSE_OPTIONS = [
  "General Inquiry",
  "Partnership",
  "Ad Placement",
  "Technical Support",
  "Enterprise Workflow",
  "Press & Media",
] as const;

const baseInputClassName =
  "w-full rounded-2xl border border-vault-border bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 hover:border-slate-300 hover:bg-white focus:border-vault-blue focus:ring-4 focus:ring-blue-100";

interface ContactResponse {
  ok: boolean;
  mode?: "smtp" | "mailto" | "noop";
  message?: string;
  mailtoUrl?: string;
  challenge?: MathCaptchaChallenge;
}

export function ContactForm() {
  const [formValues, setFormValues] = useState({
    name: "",
    email: "",
    company: "",
    purpose: PURPOSE_OPTIONS[0],
    message: "",
    website: "",
    captchaAnswer: "",
  });
  const [status, setStatus] = useState<{
    tone: "success" | "error";
    message: string;
  } | null>(null);
  const [challenge, setChallenge] = useState<MathCaptchaChallenge | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isLoadingChallenge, setIsLoadingChallenge] = useState(true);
  const [isSending, setIsSending] = useState(false);

  const updateField = (name: keyof typeof formValues, value: string) => {
    setFormValues((current) => ({
      ...current,
      [name]: value,
    }));
  };

  const loadChallenge = async () => {
    setIsLoadingChallenge(true);

    try {
      const response = await fetch("/api/contact", {
        method: "GET",
        cache: "no-store",
      });
      const payload = (await response.json()) as ContactResponse;

      if (!response.ok || !payload.challenge) {
        throw new Error("Could not load the security challenge.");
      }

      setChallenge(payload.challenge);
    } catch (error) {
      setStatus({
        tone: "error",
        message:
          error instanceof Error
            ? error.message
            : "Could not load the security challenge right now.",
      });
    } finally {
      setIsLoadingChallenge(false);
    }
  };

  useEffect(() => {
    void loadChallenge();
  }, []);

  useEffect(() => {
    if (!toastMessage) {
      return;
    }

    const timer = window.setTimeout(() => {
      setToastMessage(null);
    }, 4200);

    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  const isHumanVerified = useMemo(() => {
    if (!challenge) {
      return false;
    }

    return Number(formValues.captchaAnswer) === challenge.left + challenge.right;
  }, [challenge, formValues.captchaAnswer]);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!challenge) {
      setStatus({
        tone: "error",
        message: "The security challenge is still loading. Please wait a moment.",
      });
      return;
    }

    setIsSending(true);
    setStatus(null);
    setToastMessage(null);

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formValues,
          captchaLeft: challenge.left,
          captchaRight: challenge.right,
          captchaToken: challenge.token,
        }),
      });

      const payload = (await response.json()) as ContactResponse;

      if (!response.ok || !payload.ok) {
        throw new Error(payload.message ?? "We could not send your message right now.");
      }

      setToastMessage(
        payload.message ??
          "Transmission received. Your note is now in the Logic Vault operations flow."
      );
      setFormValues({
        name: "",
        email: "",
        company: "",
        purpose: PURPOSE_OPTIONS[0],
        message: "",
        website: "",
        captchaAnswer: "",
      });

      if (payload.mailtoUrl) {
        window.location.href = payload.mailtoUrl;
      }
    } catch (error) {
      setStatus({
        tone: "error",
        message:
          error instanceof Error
            ? error.message
            : "We could not send your note. Please try again in a moment.",
      });
    } finally {
      setIsSending(false);
      void loadChallenge();
    }
  };

  return (
    <div className="relative grid gap-6 lg:grid-cols-[1.25fr_0.75fr]">
      <section className="rounded-[28px] border border-vault-border bg-slate-50 p-5 shadow-sm sm:p-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-400">
              Contact Logic Vault
            </p>
            <h2 className="mt-2 text-2xl font-black tracking-[-0.04em] text-slate-950">
              Tell us what you need
            </h2>
          </div>
          <a
            href="mailto:ops@logicvault.org"
            className="rounded-full bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-vault-blue transition hover:text-slate-950"
          >
            ops@logicvault.org
          </a>
        </div>

        <form className="mt-6 space-y-5" onSubmit={handleSubmit}>
          <div className="grid gap-5 md:grid-cols-2">
            <label className="space-y-2">
              <span className="block text-sm font-semibold text-slate-700">Name</span>
              <input
                className={baseInputClassName}
                value={formValues.name}
                onChange={(event) => updateField("name", event.target.value)}
                placeholder="Jane Doe"
                required
              />
            </label>

            <label className="space-y-2">
              <span className="block text-sm font-semibold text-slate-700">Email</span>
              <input
                type="email"
                className={baseInputClassName}
                value={formValues.email}
                onChange={(event) => updateField("email", event.target.value)}
                placeholder="jane@company.com"
                required
              />
            </label>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            <label className="space-y-2">
              <span className="block text-sm font-semibold text-slate-700">
                Company or team
              </span>
              <input
                className={baseInputClassName}
                value={formValues.company}
                onChange={(event) => updateField("company", event.target.value)}
                placeholder="Logic Vault Partner"
              />
            </label>

            <label className="space-y-2">
              <span className="block text-sm font-semibold text-slate-700">Purpose</span>
              <select
                className={baseInputClassName}
                value={formValues.purpose}
                onChange={(event) => updateField("purpose", event.target.value)}
              >
                {PURPOSE_OPTIONS.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <label className="hidden">
            <span>Website</span>
            <input
              tabIndex={-1}
              autoComplete="off"
              value={formValues.website}
              onChange={(event) => updateField("website", event.target.value)}
            />
          </label>

          <div className="rounded-[24px] border border-cyan-100 bg-[linear-gradient(135deg,#eff6ff_0%,#ecfeff_100%)] p-4">
            <div className="flex items-start gap-3">
              <span className="inline-flex size-11 shrink-0 items-center justify-center rounded-2xl bg-white text-vault-blue shadow-sm">
                <ShieldCheck className="size-5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-400">
                  Security Challenge
                </p>
                <label className="mt-3 block space-y-2">
                  <span className="block text-sm font-semibold text-slate-800">
                    {challenge
                      ? `Human Verification: What is ${challenge.left} + ${challenge.right}?`
                      : "Human Verification: Loading challenge..."}
                  </span>
                  <input
                    type="number"
                    inputMode="numeric"
                    className={baseInputClassName}
                    value={formValues.captchaAnswer}
                    onChange={(event) => updateField("captchaAnswer", event.target.value)}
                    placeholder="Enter the sum"
                    disabled={isLoadingChallenge}
                  />
                </label>
                <p className="mt-3 text-sm text-slate-500">
                  {isLoadingChallenge
                    ? "Loading verification..."
                    : isHumanVerified
                      ? "Verified. You can send your message now."
                      : "Enter the correct answer to activate the send button."}
                </p>
              </div>
            </div>
          </div>

          <label className="space-y-2">
            <span className="block text-sm font-semibold text-slate-700">Message</span>
            <textarea
              className={`${baseInputClassName} min-h-40 resize-y`}
              value={formValues.message}
              onChange={(event) => updateField("message", event.target.value)}
              placeholder="Tell us about your project, timeline, or the kind of placement you want."
              required
            />
          </label>

          {status ? (
            <div
              className={`rounded-2xl px-4 py-3 text-sm ${
                status.tone === "success"
                  ? "border border-emerald-100 bg-emerald-50 text-emerald-700"
                  : "border border-rose-100 bg-rose-50 text-rose-700"
              }`}
            >
              {status.message}
            </div>
          ) : null}

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-slate-500">
              For partnerships and ad placement, include audience, timing, and your preferred
              region.
            </p>
            <button
              type="submit"
              disabled={isSending || isLoadingChallenge || !isHumanVerified}
              className="inline-flex items-center justify-center rounded-full bg-vault-red px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#c92b27] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isSending ? "Sending..." : "Send Message"}
            </button>
          </div>
        </form>
      </section>

      <section className="rounded-[28px] border border-vault-border bg-white p-5 shadow-sm sm:p-6">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-400">
          Best fit
        </p>
        <div className="mt-4 space-y-4">
          <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
            <p className="text-sm font-bold text-slate-950">Partnerships</p>
            <p className="mt-2 text-sm leading-7 text-slate-500">
              Tell us what you want to build together, which markets matter, and what success
              looks like.
            </p>
          </div>
          <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
            <p className="text-sm font-bold text-slate-950">Ad placement</p>
            <p className="mt-2 text-sm leading-7 text-slate-500">
              Share your preferred placement, creative format, target region, and campaign dates.
            </p>
          </div>
          <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
            <p className="text-sm font-bold text-slate-950">Support</p>
            <p className="mt-2 text-sm leading-7 text-slate-500">
              Include the exact tool name, a sample file type, and the issue you want us to help
              with.
            </p>
          </div>
        </div>
      </section>

      {toastMessage ? (
        <div className="pointer-events-none fixed bottom-6 right-4 z-50 max-w-sm sm:right-6">
          <div className="overflow-hidden rounded-[24px] border border-cyan-200 bg-[linear-gradient(135deg,#0f172a_0%,#12233b_62%,#13345a_100%)] px-5 py-4 text-white shadow-[0_24px_80px_rgba(8,47,73,0.38)]">
            <div className="flex items-start gap-3">
              <span className="inline-flex size-11 shrink-0 items-center justify-center rounded-2xl bg-cyan-400/15 text-cyan-200">
                <Sparkles className="size-5" />
              </span>
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.24em] text-cyan-200/80">
                  Transmission Received
                </p>
                <p className="mt-2 text-sm leading-7 text-slate-100">{toastMessage}</p>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
