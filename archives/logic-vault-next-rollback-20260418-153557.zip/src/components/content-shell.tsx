import Link from "next/link";
import {
  ArrowRight,
  CheckCircle2,
  DatabaseZap,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react";

import { AdSlot } from "@/components/ad-slot";
import { JsonLd } from "@/components/json-ld";
import { type AppLocale, localizePath } from "@/lib/i18n";
import { buildBreadcrumbSchema, buildWebPageSchema } from "@/lib/seo";

const ACCENT_STYLES = {
  red: {
    shell: "from-rose-50 via-white to-white",
    badge: "bg-rose-100 text-rose-700",
    icon: "bg-vault-red text-white",
    ring: "bg-rose-200/70",
  },
  blue: {
    shell: "from-blue-50 via-white to-white",
    badge: "bg-blue-100 text-blue-700",
    icon: "bg-vault-blue text-white",
    ring: "bg-blue-200/70",
  },
  green: {
    shell: "from-emerald-50 via-white to-white",
    badge: "bg-emerald-100 text-emerald-700",
    icon: "bg-emerald-500 text-white",
    ring: "bg-emerald-200/70",
  },
  amber: {
    shell: "from-amber-50 via-white to-white",
    badge: "bg-amber-100 text-amber-700",
    icon: "bg-amber-500 text-white",
    ring: "bg-amber-200/70",
  },
  slate: {
    shell: "from-slate-100 via-white to-white",
    badge: "bg-slate-100 text-slate-700",
    icon: "bg-slate-900 text-white",
    ring: "bg-slate-200/70",
  },
} as const;

interface ContentShellProps {
  locale?: AppLocale | null;
  eyebrow: string;
  title: string;
  intro: string;
  icon: LucideIcon;
  accent?: keyof typeof ACCENT_STYLES;
  highlights: string[];
  visualTitle: string;
  visualBody: string;
  path: string;
  primaryAction?: {
    label: string;
    href: string;
  };
  secondaryAction?: {
    label: string;
    href: string;
  };
  children: React.ReactNode;
}

export function ContentShell({
  locale = null,
  eyebrow,
  title,
  intro,
  icon: Icon,
  accent = "blue",
  highlights,
  visualTitle,
  visualBody,
  path,
  primaryAction,
  secondaryAction,
  children,
}: ContentShellProps) {
  const accentStyles = ACCENT_STYLES[accent];
  const assuranceCards = [
    {
      title: "Plain-language policy",
      body: "Every trust page is written for fast scanning, with direct statements before legal detail.",
      icon: CheckCircle2,
    },
    {
      title: "Data-minimal posture",
      body: "The platform favors narrow processing, short retention windows, and fewer hidden data paths.",
      icon: DatabaseZap,
    },
    {
      title: "Operational clarity",
      body: "Privacy, security, terms, and compliance are treated as active product surfaces.",
      icon: ShieldCheck,
    },
  ];

  return (
    <main className="bg-[#f3f4f6] px-4 pb-16 pt-24 sm:px-6 lg:px-8">
      <JsonLd
        data={[
          buildWebPageSchema({
            title,
            description: intro,
            path,
            locale,
          }),
          buildBreadcrumbSchema([
            { name: "Home", path: "/", locale },
            { name: title, path, locale },
          ]),
        ]}
      />
      <div className="mx-auto max-w-6xl">
        <section
          className={`overflow-hidden rounded-[36px] border border-vault-border bg-gradient-to-br ${accentStyles.shell} p-6 shadow-sm sm:p-8`}
        >
          <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
            <div>
              <span
                className={`inline-flex items-center rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em] ${accentStyles.badge}`}
              >
                {eyebrow}
              </span>
              <h1 className="mt-5 text-4xl font-black tracking-[-0.05em] text-slate-950 sm:text-5xl">
                {title}
              </h1>
              <p className="mt-5 max-w-2xl text-base leading-8 text-slate-600 sm:text-lg">
                {intro}
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                {primaryAction ? (
                  <Link
                    href={localizePath(primaryAction.href, locale)}
                    className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800"
                  >
                    {primaryAction.label}
                    <ArrowRight className="size-4" />
                  </Link>
                ) : null}
                {secondaryAction ? (
                  <Link
                    href={localizePath(secondaryAction.href, locale)}
                    className="inline-flex items-center gap-2 rounded-full border border-vault-border bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:text-slate-950"
                  >
                    {secondaryAction.label}
                  </Link>
                ) : null}
              </div>

              <div className="mt-8 flex flex-wrap gap-3">
                {highlights.map((highlight) => (
                  <span
                    key={highlight}
                    className="rounded-full border border-white/80 bg-white/90 px-4 py-2 text-sm text-slate-600 shadow-sm"
                  >
                    {highlight}
                  </span>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="relative overflow-hidden rounded-[32px] border border-white/80 bg-white/85 p-6 shadow-sm">
                <div
                  className={`absolute -right-10 -top-10 size-36 rounded-full blur-2xl ${accentStyles.ring}`}
                />
                <div className="absolute inset-x-6 bottom-6 top-24 rounded-[28px] border border-dashed border-slate-200/80" />

                <div className="relative">
                  <div
                    className={`inline-flex size-14 items-center justify-center rounded-2xl ${accentStyles.icon}`}
                  >
                    <Icon className="size-7" />
                  </div>
                  <p className="mt-5 text-lg font-black text-slate-950">{visualTitle}</p>
                  <p className="mt-3 max-w-sm text-sm leading-7 text-slate-500">{visualBody}</p>
                </div>

                <div className="relative mt-8 space-y-3">
                  {highlights.slice(0, 3).map((highlight, index) => (
                    <div
                      key={highlight}
                      className={`rounded-2xl border border-white/80 bg-white/90 px-4 py-3 shadow-sm ${
                        index === 1 ? "ml-5" : index === 2 ? "mr-5" : ""
                      }`}
                    >
                      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
                        Logic Vault
                      </p>
                      <p className="mt-2 text-sm font-medium text-slate-700">{highlight}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <AdSlot slot="contentInline" className="mt-8" />

        <section className="mt-8 rounded-[36px] border border-vault-border bg-white p-5 shadow-sm sm:p-8">
          <div className="overflow-hidden rounded-[30px] border border-slate-100 bg-[radial-gradient(circle_at_top_left,rgba(50,98,149,0.15),transparent_32%),radial-gradient(circle_at_bottom_right,rgba(16,185,129,0.12),transparent_24%),linear-gradient(135deg,#ffffff_0%,#f8fafc_100%)] p-6 sm:p-8">
            <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(300px,0.85fr)]">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.28em] text-slate-400">
                  Trust architecture
                </p>
                <h2 className="mt-3 text-3xl font-black tracking-[-0.04em] text-slate-950">
                  Policies designed like product workflows
                </h2>
                <p className="mt-4 text-sm leading-8 text-slate-600">
                  These pages should feel as usable as the tools themselves. Instead of plain
                  static text, each policy section is organized around readable commitments,
                  practical boundaries, and clear operating notes that help visitors understand how
                  Logic Vault handles sensitive financial workflows.
                </p>
              </div>

              <div className="grid gap-4">
                {assuranceCards.map((card) => {
                  const CardIcon = card.icon;

                  return (
                    <div
                      key={card.title}
                      className="rounded-[24px] border border-white/80 bg-white/85 p-5 shadow-sm backdrop-blur"
                    >
                      <div className="flex items-start gap-3">
                        <span
                          className={`flex size-10 shrink-0 items-center justify-center rounded-2xl ${accentStyles.icon}`}
                        >
                          <CardIcon className="size-5" />
                        </span>
                        <div>
                          <p className="text-sm font-bold text-slate-950">{card.title}</p>
                          <p className="mt-2 text-sm leading-7 text-slate-500">{card.body}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <div className="lv-content-notes mt-8 space-y-6 text-sm leading-8 text-slate-600">
          {children}
        </div>
      </div>
    </main>
  );
}
