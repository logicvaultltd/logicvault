"use client";

import Link from "next/link";
import { ArrowRight, Search, ShieldCheck, Sparkles, Workflow } from "lucide-react";
import { useDeferredValue, useMemo, useState } from "react";
import { usePathname } from "next/navigation";

import { AdSlot } from "@/components/ad-slot";
import { ExitIntentModal } from "@/components/exit-intent-modal";
import { SocialTicker } from "@/components/social-ticker";
import { ToolCard } from "@/components/tool-card";
import { getDictionary, getLocaleFromPathname, localizePath } from "@/lib/i18n";
import { TOOLS } from "@/lib/tools-registry";

function injectSponsoredCards<T>(items: T[], interval = 8) {
  const output: Array<T | { sponsored: true; id: string }> = [];

  items.forEach((item, index) => {
    output.push(item);

    if ((index + 1) % interval === 0 && index + 1 < items.length) {
      output.push({ sponsored: true, id: `sponsored-${index}` });
    }
  });

  return output;
}

export function Dashboard({
  initialActivities = [],
}: {
  initialActivities?: Array<{
    id: number | string;
    city: string | null;
    file_type: string | null;
    tool_slug: string | null;
  }>;
}) {
  const pathname = usePathname();
  const activeLocale = getLocaleFromPathname(pathname);
  const copy = getDictionary(activeLocale);
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const deferredQuery = useDeferredValue(query);
  const isSearchVisible = searchOpen || query.trim().length > 0;
  const filteredTools = useMemo(() => {
    const normalizedQuery = deferredQuery.trim().toLowerCase();

    if (normalizedQuery.length === 0) {
      return TOOLS;
    }

    return TOOLS.filter((tool) => {
      const haystack = [
        tool.title,
        tool.description,
        tool.category,
        ...(tool.keywords ?? []),
      ]
        .join(" ")
        .toLowerCase();

      return haystack.includes(normalizedQuery);
    });
  }, [deferredQuery]);
  const featuredTools = useMemo(
    () => filteredTools.filter((tool) => tool.featured).slice(0, 8),
    [filteredTools]
  );
  const secondaryTools = useMemo(
    () => filteredTools.filter((tool) => !tool.featured),
    [filteredTools]
  );
  const secondaryItems = useMemo(
    () => injectSponsoredCards(secondaryTools),
    [secondaryTools]
  );
  const featuredToolCount = useMemo(
    () => TOOLS.filter((tool) => tool.featured).slice(0, 8).length,
    []
  );

  return (
    <main className="bg-[#f3f4f6] pt-24">
      <section className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
        <section className="overflow-hidden rounded-[36px] border border-vault-border bg-[radial-gradient(circle_at_top_left,rgba(50,98,149,0.18),transparent_34%),radial-gradient(circle_at_bottom_right,rgba(16,185,129,0.14),transparent_24%),linear-gradient(135deg,#ffffff_0%,#f8fbff_48%,#eef5fb_100%)] shadow-sm">
          <div className="grid gap-10 px-5 py-8 sm:px-8 sm:py-10 lg:grid-cols-[minmax(0,1.15fr)_minmax(290px,0.85fr)] lg:px-10">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-400">
                {copy.heroEyebrow}
              </p>
              <h1 className="mt-4 max-w-3xl text-4xl font-black tracking-[-0.05em] text-slate-950 sm:text-5xl">
                {copy.heroTitle}
              </h1>
              <p className="mt-4 max-w-2xl text-base leading-8 text-slate-600">
                {copy.heroBody}
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Link
                  href="#tools"
                  className="inline-flex items-center justify-center rounded-full bg-vault-blue px-6 py-3 text-sm font-semibold text-white transition hover:bg-[#2b557f]"
                >
                  {copy.heroPrimaryCta}
                </Link>
                <button
                  id="tool-search"
                  type="button"
                  onClick={() => setSearchOpen((current) => !current)}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-vault-border bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:text-slate-950"
                >
                  <Search className="size-4" />
                  {copy.heroSecondaryCta}
                </button>
              </div>

              {isSearchVisible ? (
                <div className="mt-5 max-w-2xl rounded-[24px] border border-vault-border bg-white/90 p-4 backdrop-blur">
                  <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-400">
                    {copy.heroSearchLabel}
                  </p>
                  <label className="mt-3 flex items-center gap-3 rounded-2xl border border-vault-border bg-slate-50 px-4 py-3">
                    <Search className="size-5 text-slate-400" />
                    <input
                      value={query}
                      onChange={(event) => setQuery(event.target.value)}
                      placeholder={copy.searchPlaceholder}
                      className="w-full bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-400"
                    />
                  </label>
                </div>
              ) : null}
            </div>

            <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1">
              <div className="rounded-[26px] border border-white/70 bg-white/85 p-5 backdrop-blur">
                <div className="flex items-center gap-3">
                  <span className="flex size-11 items-center justify-center rounded-2xl bg-blue-50 text-vault-blue">
                    <Workflow className="size-5" />
                  </span>
                  <div>
                    <p className="text-sm font-bold text-slate-950">{copy.heroFeaturedLabel}</p>
                    <p className="text-sm text-slate-500">
                      {featuredToolCount} high-intent tools ready now
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-[26px] border border-white/70 bg-white/85 p-5 backdrop-blur">
                <div className="flex items-center gap-3">
                  <span className="flex size-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600">
                    <ShieldCheck className="size-5" />
                  </span>
                  <div>
                    <p className="text-sm font-bold text-slate-950">Private by default</p>
                    <p className="text-sm text-slate-500">
                      Clear processing states and safer handling for finance work
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-[26px] border border-white/70 bg-white/85 p-5 backdrop-blur">
                <div className="flex items-center gap-3">
                  <span className="flex size-11 items-center justify-center rounded-2xl bg-violet-50 text-violet-600">
                    <Sparkles className="size-5" />
                  </span>
                  <div>
                    <p className="text-sm font-bold text-slate-950">Built for repeat use</p>
                    <p className="text-sm text-slate-500">
                      Fast conversions, calculators, and exports without extra clutter
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="mt-8">
          <AdSlot slot="leaderboard" />
        </div>

        <div className="mt-6">
          <SocialTicker initialItems={initialActivities} />
        </div>

        <div id="tools" className="mt-8 space-y-10">
          {filteredTools.length > 0 ? (
            <>
              <section>
                <div className="mb-4 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-400">
                      {copy.heroFeaturedLabel}
                    </p>
                    <p className="mt-1 text-sm text-slate-500">
                      Start with the most-used Logic Vault workflows.
                    </p>
                  </div>
                  {query ? (
                    <button
                      type="button"
                      onClick={() => {
                        setQuery("");
                        setSearchOpen(false);
                      }}
                      className="inline-flex items-center gap-2 rounded-full border border-vault-border bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:text-slate-950"
                    >
                      Clear search
                    </button>
                  ) : null}
                </div>
                <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                  {featuredTools.map((tool) => (
                    <ToolCard
                      key={tool.id}
                      tool={tool}
                      href={localizePath(`/tool/${tool.id}`, activeLocale)}
                    />
                  ))}
                </div>
              </section>

              {secondaryItems.length > 0 ? (
                <section>
                  <div className="mb-4 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-400">
                        All tools
                      </p>
                      <p className="mt-1 text-sm text-slate-500">
                        Browse the wider Logic Vault library for document and finance work.
                      </p>
                    </div>
                    <Link
                      href="#tools"
                      className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 transition hover:text-slate-950"
                    >
                      Browse grid
                      <ArrowRight className="size-4" />
                    </Link>
                  </div>
                  <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                    {secondaryItems.map((item) =>
                      "sponsored" in item ? (
                        <div
                          key={item.id}
                          className="rounded-[28px] border border-vault-border bg-white p-6 sm:col-span-2 xl:col-span-4"
                        >
                          <AdSlot slot="gridFeed" label={copy.sponsored} />
                          <p className="mt-3 text-sm text-slate-500">{copy.sponsoredBody}</p>
                        </div>
                      ) : (
                        <ToolCard
                          key={item.id}
                          tool={item}
                          href={localizePath(`/tool/${item.id}`, activeLocale)}
                        />
                      )
                    )}
                  </div>
                </section>
              ) : null}
            </>
          ) : (
            <div className="rounded-[28px] border border-vault-border bg-white px-6 py-12 text-center">
              <h1 className="text-2xl font-black text-slate-950">{copy.noToolsTitle}</h1>
              <p className="mt-3 text-sm text-slate-500">{copy.noToolsBody}</p>
            </div>
          )}
        </div>
      </section>

      <ExitIntentModal locale={activeLocale} />
    </main>
  );
}
