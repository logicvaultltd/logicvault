"use client";

import { useEffect, useState } from "react";

import { useGlobalSiteConfig } from "@/components/global-ad-provider";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { markTrustpilotCompleted } from "@/lib/trustpilot";

const EXIT_INTENT_KEY = "logic-vault:exit-intent-dismissed";

export function ExitIntentModal({ locale }: { locale: string | null }) {
  const config = useGlobalSiteConfig();
  const copy = getDictionary(resolveLocale(locale));
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!config.exitIntentEnabled) {
      return;
    }

    if (window.localStorage.getItem(EXIT_INTENT_KEY) === "true") {
      return;
    }

    const handleMouseLeave = (event: MouseEvent) => {
      if (event.clientY > 20) {
        return;
      }

      setOpen(true);
    };

    window.addEventListener("mouseout", handleMouseLeave);

    return () => window.removeEventListener("mouseout", handleMouseLeave);
  }, [config.exitIntentEnabled]);

  if (!open || !config.exitIntentEnabled) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-950/45 px-4">
      <div className="w-full max-w-lg rounded-[28px] border border-vault-border bg-white p-6 shadow-2xl">
        <h2 className="text-2xl font-black text-slate-950">{copy.exitIntentTitle}</h2>
        <p className="mt-3 text-sm leading-7 text-slate-500">
          {config.exitIntentMessage || copy.exitIntentBody}
        </p>

        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <a
            href={config.trustpilotUrl}
            target="_blank"
            rel="noreferrer"
            onClick={() => {
              markTrustpilotCompleted();
              window.localStorage.setItem(EXIT_INTENT_KEY, "true");
              setOpen(false);
            }}
            className="inline-flex flex-1 items-center justify-center rounded-full bg-vault-blue px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#2b557f]"
          >
            {copy.exitIntentPrimary}
          </a>
          <button
            type="button"
            onClick={() => {
              window.localStorage.setItem(EXIT_INTENT_KEY, "true");
              setOpen(false);
            }}
            className="inline-flex flex-1 items-center justify-center rounded-full border border-vault-border px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
          >
            {copy.exitIntentSecondary}
          </button>
        </div>
      </div>
    </div>
  );
}
