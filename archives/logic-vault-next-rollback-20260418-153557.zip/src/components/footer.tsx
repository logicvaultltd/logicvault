"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { AdSlot } from "@/components/ad-slot";
import { useGlobalSiteConfig } from "@/components/global-ad-provider";
import {
  LOCALE_LABELS,
  SUPPORTED_LOCALES,
  getDictionary,
  getLocaleFromPathname,
  localizePath,
  persistLocalePreference,
  resolveLocale,
} from "@/lib/i18n";

type FooterLink = {
  href: string;
  label: string;
};

const FOOTER_COLUMNS: Array<{
  title: string;
  links: FooterLink[];
}> = [
  {
    title: "Product",
    links: [
      { href: "/", label: "Home" },
      { href: "/#tools", label: "Tools" },
      { href: "/about", label: "About" },
    ],
  },
  {
    title: "Solutions",
    links: [
      { href: "/tool/statement-to-csv", label: "Account Statement to CSV" },
      { href: "/tool/merge-pdf", label: "Merge PDF" },
      { href: "/tool/yield-calculator", label: "Yield Calculator" },
    ],
  },
  {
    title: "Legal",
    links: [
      { href: "/privacy", label: "Privacy" },
      { href: "/terms", label: "Terms" },
      { href: "/trust", label: "Trust" },
      { href: "/security", label: "Security" },
      { href: "/compliance", label: "Compliance" },
    ],
  },
];

export function Footer() {
  const pathname = usePathname();
  const siteConfig = useGlobalSiteConfig();
  const activeLocale = getLocaleFromPathname(pathname);
  const copy = getDictionary(activeLocale);
  const unlocalizedPath = activeLocale
    ? pathname.replace(new RegExp(`^/${activeLocale}`), "") || "/"
    : pathname || "/";
  const enabledLocales = SUPPORTED_LOCALES.filter((locale) =>
    siteConfig.enabledLanguages.includes(locale)
  );
  const localeOptions = enabledLocales.length > 0 ? enabledLocales : SUPPORTED_LOCALES;

  return (
    <footer className="border-t border-[#14314b] bg-[radial-gradient(circle_at_top_left,rgba(44,109,176,0.28),transparent_28%),radial-gradient(circle_at_bottom_right,rgba(6,182,212,0.2),transparent_24%),linear-gradient(135deg,#071120_0%,#0b1f34_58%,#12324c_100%)] text-slate-200">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:px-8">
        <AdSlot slot="stickyFooter" className="mb-10" label="Ad Placement" />

        <div className="grid gap-10 lg:grid-cols-[1.2fr_repeat(3,minmax(0,1fr))]">
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <span className="relative flex size-12 shrink-0 overflow-hidden rounded-2xl border border-white/15 shadow-[0_18px_40px_rgba(7,17,32,0.25)]">
                <span className="w-1/2 bg-vault-red" />
                <span className="w-1/2 bg-vault-blue" />
                <span className="absolute inset-0 flex items-center justify-center text-xs font-black tracking-[0.2em] text-white">
                  LV
                </span>
              </span>
              <div className="min-w-0">
                <p className="text-sm font-black tracking-[0.26em] text-white">
                  LOGIC VAULT
                </p>
                <p className="mt-2 max-w-sm text-sm leading-7 text-slate-300">
                  Private financial tools, clean document workflows, and global-first utility
                  design for modern teams.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Link
                href={localizePath("/contact", activeLocale)}
                className="inline-flex items-center rounded-full bg-[linear-gradient(135deg,#ef4444_0%,#d73d35_42%,#b91c1c_100%)] px-5 py-2.5 text-sm font-semibold text-white shadow-[0_14px_28px_rgba(185,28,28,0.26)] transition hover:translate-y-[-1px] hover:shadow-[0_18px_32px_rgba(185,28,28,0.32)]"
              >
                {copy.contact}
              </Link>
              <span className="rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-cyan-100">
                Global
              </span>
              <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100">
                Private by design
              </span>
            </div>

            <label className="inline-flex w-fit items-center gap-3 rounded-full border border-white/12 bg-white/6 px-4 py-2 text-sm text-slate-200 backdrop-blur-sm">
              <span aria-hidden="true">🌐</span>
              <select
                className="bg-transparent text-sm font-medium uppercase tracking-[0.18em] text-white outline-none"
                value={activeLocale ?? "en"}
                onChange={(event) => {
                  const nextLocale = resolveLocale(event.target.value);
                  persistLocalePreference(nextLocale);
                  window.location.href = localizePath(unlocalizedPath, nextLocale);
                }}
              >
                {localeOptions.map((locale) => (
                  <option key={locale} value={locale}>
                    {LOCALE_LABELS[locale].toUpperCase()}
                  </option>
                ))}
              </select>
            </label>
          </div>

          {FOOTER_COLUMNS.map((column) => (
            <div key={column.title}>
              <h2 className="text-sm font-bold uppercase tracking-[0.16em] text-white">
                {column.title}
              </h2>
              <ul className="mt-4 space-y-3 text-sm text-slate-300">
                {column.links.map((link) => (
                  <li key={link.href + link.label}>
                    <Link
                      href={localizePath(link.href, activeLocale)}
                      className="transition hover:text-white"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col gap-4 border-t border-white/10 pt-6 text-sm text-slate-400 sm:flex-row sm:items-center sm:justify-between">
          <p>{copy.safeFooter}</p>
          <p>© 2026 Logic Vault. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
