"use client";

import { ChevronDown, Menu, X } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";

import { useGlobalSiteConfig } from "@/components/global-ad-provider";
import {
  LOCALE_LABELS,
  SUPPORTED_LOCALES,
  getDictionary,
  getLocaleFromPathname,
  localizePath,
  persistLocalePreference,
  resolveLocale,
} from "@/lib/i18n";
import { TOOLS } from "@/lib/tools-registry";

const NAV_TOOL_GROUPS = [
  {
    title: "Organize",
    ids: ["merge-pdf", "split-pdf", "organize-pdf", "remove-pages"],
  },
  {
    title: "Optimize",
    ids: ["compress-pdf", "repair-pdf"],
  },
  {
    title: "Convert",
    ids: [
      "word-to-pdf",
      "excel-to-pdf",
      "ppt-to-pdf",
      "jpg-to-pdf",
      "pdf-to-word",
      "pdf-to-excel",
      "pdf-to-ppt",
      "pdf-to-jpg",
    ],
  },
  {
    title: "Security",
    ids: ["unlock-pdf", "protect-pdf", "sign-pdf", "watermark-pdf"],
  },
  {
    title: "Intelligence",
    ids: [
      "statement-to-csv",
      "ai-summarizer",
      "ocr-pdf",
      "ai-expense-categorizer",
      "financial-health-score",
    ],
  },
  {
    title: "Financial Tools",
    ids: [
      "yield-calculator",
      "roi-tracker",
      "landed-cost-calculator",
      "marketing-budget-tool",
      "tax-estimator",
      "business-valuation-tool",
    ],
  },
].map((group) => ({
  ...group,
  tools: group.ids
    .map((id) => TOOLS.find((tool) => tool.id === id))
    .filter((tool): tool is (typeof TOOLS)[number] => Boolean(tool)),
}));

export function Header() {
  const pathname = usePathname();
  const siteConfig = useGlobalSiteConfig();
  const [toolsOpen, setToolsOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const toolsMenuRef = useRef<HTMLDivElement | null>(null);
  const activeLocale = getLocaleFromPathname(pathname);
  const copy = getDictionary(activeLocale);
  const unlocalizedPath = activeLocale
    ? pathname.replace(new RegExp(`^/${activeLocale}`), "") || "/"
    : pathname || "/";
  const localeOptions = useMemo(() => {
    const enabledLocales = SUPPORTED_LOCALES.filter((locale) =>
      siteConfig.enabledLanguages.includes(locale)
    );

    return enabledLocales.length > 0 ? enabledLocales : SUPPORTED_LOCALES;
  }, [siteConfig.enabledLanguages]);

  useEffect(() => {
    const handlePointerDown = (event: MouseEvent) => {
      if (
        toolsMenuRef.current &&
        event.target instanceof Node &&
        !toolsMenuRef.current.contains(event.target)
      ) {
        setToolsOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setToolsOpen(false);
      }
    };

    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  const closeMenus = () => {
    setToolsOpen(false);
    setMobileMenuOpen(false);
  };

  const languagePicker = (
    <label className="inline-flex items-center gap-2 rounded-full border border-vault-border bg-slate-50 px-3 py-2 text-sm text-slate-600">
      <span aria-hidden="true">🌐</span>
      <select
        className="max-w-[190px] bg-transparent font-medium uppercase tracking-[0.14em] text-slate-700 outline-none"
        value={activeLocale ?? "en"}
        onChange={(event) => {
          const nextLocale = resolveLocale(event.target.value);
          persistLocalePreference(nextLocale);
          window.location.href = localizePath(unlocalizedPath, nextLocale);
        }}
      >
        {localeOptions.map((locale) => (
          <option key={locale} value={locale}>
            {LOCALE_LABELS[locale].toUpperCase()}
          </option>
        ))}
      </select>
    </label>
  );

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-vault-border bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4 sm:px-6 lg:px-8">
        <Link
          href={localizePath("/", activeLocale)}
          onClick={closeMenus}
          className="flex items-center gap-3"
        >
          <span className="relative flex size-10 shrink-0 overflow-hidden rounded-xl border border-vault-border">
            <span className="w-1/2 bg-vault-red" />
            <span className="w-1/2 bg-vault-blue" />
            <span className="absolute inset-0 flex items-center justify-center text-xs font-black tracking-[0.2em] text-white">
              LV
            </span>
          </span>
          <span className="text-sm font-black tracking-[0.3em] text-slate-950">
            LOGIC VAULT
          </span>
        </Link>

        <button
          type="button"
          onClick={() => setMobileMenuOpen((current) => !current)}
          className="inline-flex size-11 items-center justify-center rounded-2xl border border-vault-border bg-white text-slate-700 transition hover:border-slate-300 hover:text-slate-950 md:hidden"
          aria-label="Open navigation menu"
          aria-expanded={mobileMenuOpen}
        >
          {mobileMenuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>

        <nav className="hidden items-center gap-5 text-sm font-medium text-slate-600 md:flex">
          <Link
            href={localizePath("/", activeLocale)}
            onClick={closeMenus}
            className="transition hover:text-slate-950"
          >
            {copy.home}
          </Link>
          <div
            ref={toolsMenuRef}
            className="relative"
            onMouseEnter={() => setToolsOpen(true)}
            onMouseLeave={() => setToolsOpen(false)}
          >
            <button
              type="button"
              onClick={() => setToolsOpen((current) => !current)}
              aria-expanded={toolsOpen}
              className="inline-flex items-center gap-1.5 transition hover:text-slate-950"
            >
              {copy.tools}
              <ChevronDown
                className={`size-4 transition ${toolsOpen ? "rotate-180 text-slate-950" : ""}`}
              />
            </button>
            <div
              className={`absolute right-0 top-full z-50 w-[min(92vw,760px)] pt-3 transition duration-200 ${
                toolsOpen
                  ? "visible translate-y-0 opacity-100"
                  : "pointer-events-none invisible -translate-y-1 opacity-0"
              }`}
            >
              <div className="rounded-[28px] border border-vault-border bg-white p-6 shadow-utility">
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {NAV_TOOL_GROUPS.map((group) => (
                    <div key={group.title}>
                      <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-400">
                        {group.title}
                      </p>
                      <div className="mt-3 space-y-2">
                        {group.tools.map((tool) => (
                          <Link
                            key={tool.id}
                            href={localizePath(`/tool/${tool.id}`, activeLocale)}
                            onClick={closeMenus}
                            className="block rounded-2xl px-3 py-2 text-sm text-slate-600 transition hover:bg-slate-50 hover:text-slate-950"
                          >
                            {tool.title}
                          </Link>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <Link
            href={localizePath("/about", activeLocale)}
            onClick={closeMenus}
            className="transition hover:text-slate-950"
          >
            {copy.about}
          </Link>
          <Link
            href={localizePath("/contact", activeLocale)}
            onClick={closeMenus}
            className="inline-flex items-center rounded-full bg-vault-red px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#c92b27]"
          >
            {copy.contact}
          </Link>
          {languagePicker}
        </nav>
      </div>

      {mobileMenuOpen ? (
        <div className="border-t border-vault-border bg-white px-4 pb-5 pt-3 shadow-sm md:hidden">
          <nav className="mx-auto max-w-6xl space-y-3 text-sm font-semibold text-slate-700">
            <Link
              href={localizePath("/", activeLocale)}
              onClick={closeMenus}
              className="block rounded-2xl px-4 py-3 transition hover:bg-slate-50 hover:text-slate-950"
            >
              {copy.home}
            </Link>

            <details className="rounded-2xl border border-vault-border bg-slate-50 px-4 py-3">
              <summary className="cursor-pointer text-slate-950">{copy.tools}</summary>
              <div className="mt-4 grid gap-5">
                {NAV_TOOL_GROUPS.map((group) => (
                  <div key={group.title}>
                    <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-400">
                      {group.title}
                    </p>
                    <div className="mt-2 grid gap-2">
                      {group.tools.map((tool) => (
                        <Link
                          key={tool.id}
                          href={localizePath(`/tool/${tool.id}`, activeLocale)}
                          onClick={closeMenus}
                          className="rounded-xl bg-white px-3 py-2 text-sm text-slate-600 transition hover:text-slate-950"
                        >
                          {tool.title}
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </details>

            <Link
              href={localizePath("/about", activeLocale)}
              onClick={closeMenus}
              className="block rounded-2xl px-4 py-3 transition hover:bg-slate-50 hover:text-slate-950"
            >
              {copy.about}
            </Link>
            <Link
              href={localizePath("/contact", activeLocale)}
              onClick={closeMenus}
              className="block rounded-2xl bg-vault-red px-4 py-3 text-center text-white transition hover:bg-[#c92b27]"
            >
              {copy.contact}
            </Link>
            <div className="px-1 pt-2">{languagePicker}</div>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
