"use client";

import { CheckCircle2, LoaderCircle } from "lucide-react";

type ProcessingState = "idle" | "uploading" | "processing" | "ready" | "error";

interface ProcessingStatusProps {
  status: ProcessingState;
  progress: number;
  labels: {
    uploading: string;
    processing: string;
    ready: string;
  };
}

export function ProcessingStatus({
  status,
  progress,
  labels,
}: ProcessingStatusProps) {
  if (status === "idle" || status === "error") {
    return null;
  }

  return (
    <div className="w-full rounded-2xl border border-vault-border bg-slate-50 px-4 py-4">
      <div className="flex items-center justify-between text-sm font-medium text-slate-600">
        <span className="inline-flex items-center gap-2">
          {status === "ready" ? (
            <CheckCircle2 className="size-4 text-emerald-600" />
          ) : (
            <LoaderCircle className="size-4 animate-spin text-emerald-600" />
          )}
          {status === "uploading"
            ? labels.uploading
            : status === "processing"
              ? labels.processing
              : labels.ready}
        </span>
        <span>{progress}%</span>
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-emerald-100">
        <div
          className="h-full rounded-full bg-[#10B981] transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}
