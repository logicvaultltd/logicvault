"use client";

import { useMemo } from "react";
import { Star } from "lucide-react";

import { useGlobalSiteConfig } from "@/components/global-ad-provider";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { markTrustpilotCompleted } from "@/lib/trustpilot";

interface RatingModalProps {
  locale: string | null;
  visitCount: number;
  open: boolean;
  onClose: () => void;
}

export function RatingModal({
  locale,
  visitCount,
  open,
  onClose,
}: RatingModalProps) {
  const config = useGlobalSiteConfig();
  const copy = getDictionary(resolveLocale(locale));
  const title = useMemo(
    () => (visitCount >= 10 ? copy.rateTenth : copy.rateFirst),
    [copy.rateFirst, copy.rateTenth, visitCount]
  );

  if (!open || !config.ratingModalEnabled) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/45 px-4">
      <div className="w-full max-w-md rounded-[28px] border border-vault-border bg-white p-6 shadow-2xl">
        <div className="flex items-center gap-3">
          <span className="flex size-12 items-center justify-center rounded-2xl bg-amber-50 text-amber-500">
            <Star className="size-6" />
          </span>
          <div>
            <p className="text-lg font-black text-slate-950">{title}</p>
            <p className="mt-1 text-sm text-slate-500">{copy.rateSupport}</p>
          </div>
        </div>

        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <a
            href={config.trustpilotUrl}
            target="_blank"
            rel="noreferrer"
            onClick={() => {
              markTrustpilotCompleted();
              onClose();
            }}
            className="inline-flex flex-1 items-center justify-center rounded-full bg-vault-red px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#cb2d29]"
          >
            Trustpilot
          </a>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex flex-1 items-center justify-center rounded-full border border-vault-border px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
          >
            {copy.close}
          </button>
        </div>
      </div>
    </div>
  );
}
