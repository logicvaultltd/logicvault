"use client";

import { useEffect, useMemo, useState } from "react";

interface SocialTickerItem {
  id: number | string;
  city: string | null;
  file_type: string | null;
  tool_slug: string | null;
}

interface SocialTickerProps {
  initialItems: SocialTickerItem[];
}

function formatTickerLine(item: SocialTickerItem) {
  const city = item.city?.trim() || "a city near you";
  const fileType = item.file_type?.trim() || "statement data";
  return `A user in ${city} just converted ${fileType} with Logic Vault`;
}

export function SocialTicker({ initialItems }: SocialTickerProps) {
  const [items, setItems] = useState<SocialTickerItem[]>(initialItems);

  useEffect(() => {
    const timer = window.setInterval(async () => {
      try {
        const response = await fetch("/api/activity", { cache: "no-store" });

        if (!response.ok) {
          return;
        }

        const payload = (await response.json()) as { items: SocialTickerItem[] };

        if (payload.items.length > 0) {
          setItems(payload.items);
        }
      } catch {
        // Fallback to current items.
      }
    }, 20000);

    return () => window.clearInterval(timer);
  }, []);

  const tickerItems = useMemo(
    () =>
      (items.length > 0
        ? items
        : [
            { id: "fallback-1", city: "London", file_type: "PDF", tool_slug: "merge-pdf" },
            { id: "fallback-2", city: "Lagos", file_type: "CSV", tool_slug: "statement-to-csv" },
            { id: "fallback-3", city: "Toronto", file_type: "ROI report", tool_slug: "roi-tracker" },
          ]
      ).map((item) => ({
        ...item,
        line: formatTickerLine(item),
      })),
    [items]
  );

  return (
    <div className="overflow-hidden rounded-[28px] border border-cyan-400/20 bg-[linear-gradient(90deg,#0f172a,#0b3a5c,#0f172a)] px-4 py-3 text-sm text-cyan-100 shadow-[0_0_40px_rgba(56,189,248,0.15)]">
      <div className="social-ticker-track flex gap-10 whitespace-nowrap">
        {[...tickerItems, ...tickerItems].map((item, index) => (
          <span key={`${item.id}-${index}`} className="inline-flex items-center gap-3">
            <span className="size-2 rounded-full bg-cyan-300" />
            {item.line}
          </span>
        ))}
      </div>
    </div>
  );
}
