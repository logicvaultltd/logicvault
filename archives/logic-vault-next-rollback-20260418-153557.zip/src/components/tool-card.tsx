import Link from "next/link";

import { IconByName, getAccentClasses } from "@/lib/icon-map";
import type { ToolDefinition } from "@/lib/tools-registry";

interface ToolCardProps {
  tool: ToolDefinition;
  href?: string;
}

export function ToolCard({ tool, href = `/tool/${tool.id}` }: ToolCardProps) {
  const accent = getAccentClasses(tool.accent);

  return (
    <Link
      href={href}
      className="group flex h-full flex-col rounded-[28px] border border-vault-border bg-white p-6 transition duration-200 hover:-translate-y-1 hover:shadow-utility"
    >
      <span
        role="img"
        aria-label={`Secure tool for ${tool.title} processing`}
        className={`flex size-16 items-center justify-center rounded-2xl ${accent.icon}`}
      >
        <IconByName iconName={tool.iconName} className="size-8" />
        <span className="sr-only">{`Secure tool for ${tool.title} processing`}</span>
      </span>

      <h2 className="mt-6 text-xl font-black text-slate-950">{tool.title}</h2>
      <p className="mt-3 text-sm leading-7 text-slate-500">{tool.description}</p>
    </Link>
  );
}
