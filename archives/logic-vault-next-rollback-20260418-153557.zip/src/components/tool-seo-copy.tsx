import type { ToolDefinition } from "@/lib/tools-registry";
import { IconByName, getAccentClasses } from "@/lib/icon-map";

interface ToolSeoCopyProps {
  tool: ToolDefinition;
}

export function ToolSeoCopy({ tool }: ToolSeoCopyProps) {
  const accent = getAccentClasses(tool.accent);
  const startStep =
    tool.mode === "file"
      ? {
          title: "Choose your file",
          body: `Open ${tool.title}, add the file that matches the tool, and keep the workflow focused on the result you need.`,
        }
      : {
          title: "Enter your numbers",
          body: `Open ${tool.title}, fill in the required values, and let the calculator prepare a clean result from your inputs.`,
        };
  const workflowStep =
    tool.mode === "file"
      ? {
          title: "Confirm the details",
          body: "Add the small settings that matter, such as page ranges, statement type, or export format, without dealing with dashboard clutter.",
        }
      : {
          title: "Review the setup",
          body: "Check the short form, make sure the values are complete, and keep every assumption visible before the result is created.",
        };
  const resultStep =
    tool.mode === "file"
      ? "When the task finishes, Logic Vault prepares a branded file card with a clear download action and shows the status clearly from upload to completion."
      : "When the task finishes, Logic Vault returns a practical output that is easy to read, share, and use in a finance workflow.";
  const steps = [
    startStep,
    workflowStep,
    {
      title: "Use the result",
      body: resultStep,
    },
  ];

  return (
    <section className="mx-auto mt-8 max-w-5xl rounded-[36px] border border-vault-border bg-white p-5 shadow-sm sm:p-8">
      <div className="overflow-hidden rounded-[30px] border border-slate-100 bg-[radial-gradient(circle_at_top_left,rgba(50,98,149,0.16),transparent_32%),radial-gradient(circle_at_bottom_right,rgba(16,185,129,0.14),transparent_24%),linear-gradient(135deg,#ffffff_0%,#f8fafc_100%)] p-6 sm:p-8">
        <div className="grid gap-8 lg:grid-cols-[minmax(0,1.12fr)_minmax(280px,0.88fr)]">
          <div>
            <span
              role="img"
              aria-label={`Secure tool for ${tool.title} processing`}
              className={`flex size-14 items-center justify-center rounded-2xl ${accent.icon}`}
            >
              <IconByName iconName={tool.iconName} className="size-7" />
            </span>
            <p className="mt-5 text-xs font-semibold uppercase tracking-[0.28em] text-slate-400">
              Tool workflow
            </p>
            <h2 className="mt-3 text-3xl font-black tracking-[-0.04em] text-slate-950">
              How to use {tool.title} without losing focus
            </h2>
            <p className="mt-4 text-sm leading-8 text-slate-600">
              Logic Vault keeps the flow short on purpose. Every tool page is built around one
              clear job: add the file or values, review the essentials, and get an output that is
              ready to use. The interface avoids hidden setup screens and heavy dashboards so
              first-time visitors can finish the task quickly while repeat users still get a fast
              professional workflow.
            </p>
          </div>

          <div className="grid gap-4">
            {[
              ["Status clarity", "You always see whether the task is idle, processing, or ready."],
              ["Finance-safe wording", "Errors are written plainly so teams can correct inputs fast."],
              ["Global workflow", "The same simple pattern works across PDF, AI, and financial tools."],
            ].map(([title, body]) => (
              <div
                key={title}
                className="rounded-[24px] border border-white/70 bg-white/85 p-5 backdrop-blur"
              >
                <p className="text-sm font-bold text-slate-950">{title}</p>
                <p className="mt-2 text-sm leading-7 text-slate-500">{body}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {steps.map((step, index) => (
            <div key={step.title} className="rounded-[24px] border border-slate-200 bg-white p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-400">
                Step {String(index + 1).padStart(2, "0")}
              </p>
              <h3 className="mt-3 text-lg font-black text-slate-950">{step.title}</h3>
              <p className="mt-3 text-sm leading-7 text-slate-600">{step.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 grid gap-5 lg:grid-cols-[0.95fr_1.05fr]">
          <div className={`rounded-[28px] border px-6 py-6 ${accent.badge}`}>
            <h3 className="text-xl font-black">Built for practical output</h3>
            <p className="mt-4 text-sm leading-8">
              {tool.title} is designed for normal business files, account statements, and quick
              financial decisions without extra setup. If the wrong format is selected or a
              required value is missing, Logic Vault responds with direct guidance instead of
              technical noise. The result is a tool that feels simple enough for a new visitor and
              disciplined enough for recurring operational work.
            </p>
          </div>

          <div className="rounded-[28px] border border-slate-200 bg-slate-950 px-6 py-6 text-slate-100">
            <h3 className="text-xl font-black text-white">Why Logic Vault feels safer</h3>
            <p className="mt-4 text-sm leading-8 text-slate-300">
              Logic Vault is framed around local-first file handling, secure downloads, and zero
              clutter between the user and the job they came to finish. The same utility-first
              pattern runs across document preparation, account statement cleanup, PDF conversion,
              and finance calculators. That consistency helps people trust the product faster and
              helps search engines understand each route without thin or duplicated pages.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
