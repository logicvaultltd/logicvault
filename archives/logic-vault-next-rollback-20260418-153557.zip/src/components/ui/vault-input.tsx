import type { Ref } from "react";

import type { ToolInput } from "@/lib/tools-registry";

interface VaultInputProps {
  input: ToolInput;
  value: string;
  onChange: (name: string, value: string) => void;
  inputRef?: Ref<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>;
}

const baseClassName =
  "w-full rounded-2xl border border-vault-border bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 hover:border-slate-300 hover:bg-white focus:border-vault-blue focus:ring-4 focus:ring-blue-100";

export function VaultInput({
  input,
  value,
  onChange,
  inputRef,
}: VaultInputProps) {
  return (
    <label className="space-y-2">
      <span className="block text-sm font-semibold text-slate-700">{input.label}</span>

      {input.type === "select" ? (
        <select
          ref={inputRef as Ref<HTMLSelectElement>}
          value={value}
          onChange={(event) => onChange(input.name, event.target.value)}
          className={baseClassName}
        >
          <option value="">Choose an option</option>
          {input.options?.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      ) : input.type === "textarea" ? (
        <textarea
          ref={inputRef as Ref<HTMLTextAreaElement>}
          value={value}
          placeholder={input.placeholder}
          onChange={(event) => onChange(input.name, event.target.value)}
          className={`${baseClassName} min-h-28 resize-y`}
        />
      ) : (
        <input
          ref={inputRef as Ref<HTMLInputElement>}
          type={input.type}
          value={value}
          min={input.min}
          step={input.step}
          placeholder={input.placeholder}
          onChange={(event) => onChange(input.name, event.target.value)}
          className={baseClassName}
        />
      )}

      {input.helpText ? (
        <span className="block text-xs leading-6 text-slate-400">{input.helpText}</span>
      ) : null}
    </label>
  );
}
