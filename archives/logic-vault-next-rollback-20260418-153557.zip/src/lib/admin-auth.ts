import "server-only";

import { createHmac, timingSafeEqual } from "node:crypto";

const ADMIN_COOKIE_NAME = "logic-vault-admin";
const DEFAULT_ADMIN_EMAIL = "ops@logicvault.org";

function base64UrlEncode(value: string) {
  return Buffer.from(value)
    .toString("base64url")
    .replace(/=/g, "");
}

function base64UrlDecode(value: string) {
  return Buffer.from(value, "base64url").toString("utf8");
}

function getJwtSecret() {
  return process.env.LEX_ADMIN_SECRET ?? process.env.LEX_ADMIN_PASSWORD ?? "";
}

function normalizeEmail(value: string) {
  return value.trim().toLowerCase();
}

function signValue(value: string) {
  return createHmac("sha256", getJwtSecret()).update(value).digest("base64url");
}

export function getAdminCookieName() {
  return ADMIN_COOKIE_NAME;
}

export function verifyAdminPassword(password: string) {
  const configured = process.env.LEX_ADMIN_PASSWORD;

  if (!configured) {
    return false;
  }

  const received = Buffer.from(password);
  const expected = Buffer.from(configured);

  if (received.length !== expected.length) {
    return false;
  }

  return timingSafeEqual(received, expected);
}

export function getConfiguredAdminEmail() {
  return process.env.LEX_ADMIN_EMAIL ?? DEFAULT_ADMIN_EMAIL;
}

export function verifyAdminEmail(email: string) {
  const configured = normalizeEmail(getConfiguredAdminEmail());
  const receivedValue = normalizeEmail(email);
  const received = Buffer.from(receivedValue);
  const expected = Buffer.from(configured);

  if (received.length !== expected.length) {
    return false;
  }

  return timingSafeEqual(received, expected);
}

export function verifyAdminCredentials(email: string, password: string) {
  return verifyAdminEmail(email) && verifyAdminPassword(password);
}

export function createAdminToken(email = getConfiguredAdminEmail()) {
  const secret = getJwtSecret();

  if (!secret) {
    throw new Error("Admin secret is not configured.");
  }

  const header = base64UrlEncode(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const payload = base64UrlEncode(
    JSON.stringify({
      role: "admin",
      email: normalizeEmail(email),
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 12,
    })
  );
  const signature = signValue(`${header}.${payload}`);

  return `${header}.${payload}.${signature}`;
}

export function verifyAdminToken(token: string | undefined) {
  if (!getJwtSecret()) {
    return false;
  }

  if (!token) {
    return false;
  }

  const [header, payload, signature] = token.split(".");

  if (!header || !payload || !signature) {
    return false;
  }

  const expectedSignature = Buffer.from(signValue(`${header}.${payload}`));
  const receivedSignature = Buffer.from(signature);

  if (
    expectedSignature.length !== receivedSignature.length ||
    !timingSafeEqual(expectedSignature, receivedSignature)
  ) {
    return false;
  }

  try {
    const parsed = JSON.parse(base64UrlDecode(payload)) as {
      exp?: number;
      role?: string;
      email?: string;
    };

    return (
      parsed.role === "admin" &&
      typeof parsed.exp === "number" &&
      parsed.exp > Date.now() / 1000 &&
      normalizeEmail(parsed.email ?? "") === normalizeEmail(getConfiguredAdminEmail())
    );
  } catch {
    return false;
  }
}
