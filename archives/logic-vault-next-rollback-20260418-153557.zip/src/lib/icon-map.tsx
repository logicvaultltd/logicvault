import type { LucideProps } from "lucide-react";
import {
  Activity,
  Archive,
  BadgePercent,
  BrainCircuit,
  Briefcase,
  Calculator,
  FileOutput,
  FileSpreadsheet,
  FileText,
  Files,
  Hash,
  Image as ImageIcon,
  Languages,
  Landmark,
  Lock,
  PenTool,
  Presentation,
  RotateCw,
  Rows3,
  ScanSearch,
  ScanText,
  Scissors,
  Sparkles,
  TrendingUp,
  Trash2,
  Unlock,
  Wallet,
  Wrench,
} from "lucide-react";

import type { ToolAccent } from "@/lib/tools-registry";

export function IconByName({
  iconName,
  ...props
}: { iconName: string } & LucideProps) {
  switch (iconName) {
    case "statement-to-csv":
    case "excel-to-pdf":
    case "pdf-to-excel":
      return <FileSpreadsheet {...props} />;
    case "yield-calculator":
      return <Landmark {...props} />;
    case "roi-tracker":
      return <TrendingUp {...props} />;
    case "landed-cost-calculator":
      return <Wallet {...props} />;
    case "marketing-budget-tool":
      return <BadgePercent {...props} />;
    case "tax-estimator":
      return <Calculator {...props} />;
    case "business-valuation-tool":
      return <Briefcase {...props} />;
    case "merge-pdf":
      return <Files {...props} />;
    case "split-pdf":
      return <Scissors {...props} />;
    case "organize-pdf":
      return <Rows3 {...props} />;
    case "remove-pages":
      return <Trash2 {...props} />;
    case "compress-pdf":
      return <Archive {...props} />;
    case "repair-pdf":
      return <Wrench {...props} />;
    case "ppt-to-pdf":
    case "pdf-to-ppt":
      return <Presentation {...props} />;
    case "jpg-to-pdf":
    case "pdf-to-jpg":
      return <ImageIcon {...props} />;
    case "html-to-pdf":
    case "pdf-to-word":
    case "word-to-pdf":
      return <FileText {...props} />;
    case "rotate-pdf":
      return <RotateCw {...props} />;
    case "page-numbers":
      return <Hash {...props} />;
    case "watermark-pdf":
    case "sign-pdf":
    case "edit-pdf":
      return <PenTool {...props} />;
    case "unlock-pdf":
      return <Unlock {...props} />;
    case "protect-pdf":
      return <Lock {...props} />;
    case "ai-summarizer":
      return <Sparkles {...props} />;
    case "ai-expense-categorizer":
      return <BrainCircuit {...props} />;
    case "financial-health-score":
      return <Activity {...props} />;
    case "translate-pdf":
      return <Languages {...props} />;
    case "ocr-pdf":
      return <ScanText {...props} />;
    case "pdf-to-pdfa":
      return <FileOutput {...props} />;
    default:
      return <ScanSearch {...props} />;
  }
}

export function getAccentClasses(accent: ToolAccent) {
  switch (accent) {
    case "red":
      return {
        icon: "bg-red-50 text-vault-red",
        button: "bg-vault-red text-white hover:bg-[#cb2d29]",
        badge: "border-red-100 bg-red-50 text-vault-red",
      };
    case "blue":
      return {
        icon: "bg-blue-50 text-vault-blue",
        button: "bg-vault-blue text-white hover:bg-[#2b557f]",
        badge: "border-blue-100 bg-blue-50 text-vault-blue",
      };
    case "green":
      return {
        icon: "bg-emerald-50 text-emerald-600",
        button: "bg-emerald-600 text-white hover:bg-emerald-500",
        badge: "border-emerald-100 bg-emerald-50 text-emerald-600",
      };
    case "purple":
      return {
        icon: "bg-violet-50 text-violet-600",
        button: "bg-violet-600 text-white hover:bg-violet-500",
        badge: "border-violet-100 bg-violet-50 text-violet-600",
      };
    case "orange":
      return {
        icon: "bg-orange-50 text-orange-600",
        button: "bg-orange-500 text-white hover:bg-orange-400",
        badge: "border-orange-100 bg-orange-50 text-orange-600",
      };
    default:
      return {
        icon: "bg-slate-100 text-slate-700",
        button: "bg-slate-900 text-white hover:bg-slate-800",
        badge: "border-slate-200 bg-slate-50 text-slate-700",
      };
  }
}
