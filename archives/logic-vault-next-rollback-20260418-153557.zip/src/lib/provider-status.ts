import type { SiteConfig } from "@/lib/config-provider";
import type { ToolProvider } from "@/lib/tools-registry";

export function isProviderAvailable(
  provider: ToolProvider,
  apiStatus: SiteConfig["apiStatus"]
) {
  void provider;
  void apiStatus;

  // The current engine can complete every public tool with a local or built-in fallback,
  // so provider tags act as enhancement hints instead of hard availability gates.
  return true;
}

export function getProviderMaintenanceMessage(provider: ToolProvider) {
  if (provider === "gemini") {
    return "Maintenance mode: this AI tool is being configured right now. Please try again shortly.";
  }

  if (provider === "cloudconvert") {
    return "Maintenance mode: this conversion tool is being configured right now. Please try again shortly.";
  }

  return "Maintenance mode is active right now. Please try again shortly.";
}
